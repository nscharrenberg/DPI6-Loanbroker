package com.nscharrenberg.elect.google.gateways.application;

public class QueueName {
    public static String SEEK_JOB_REQUEST = "seekRequestQueue";
    public static String SEEK_JOB_REPLY = "seekReplyQueue";
    public static String OFFER_JOB_REQUEST = "offerRequestQueue";
    public static String OFFER_JOB_REPLY = "offerReplyQueue";
}
