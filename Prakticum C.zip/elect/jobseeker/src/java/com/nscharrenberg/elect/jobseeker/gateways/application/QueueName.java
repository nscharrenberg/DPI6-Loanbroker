package com.nscharrenberg.elect.jobseeker.gateways.application;

public class QueueName {
    public static String SEEK_JOB_REQUEST = "seekRequestQueue";
    public static String SEEK_JOB_REPLY = "seekReplyQueue";
}
